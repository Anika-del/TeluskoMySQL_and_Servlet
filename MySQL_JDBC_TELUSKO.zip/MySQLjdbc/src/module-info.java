/**
 * 
 */
/**
 * 
 */
module MySQLjdbc {
	requires java.sql;
}